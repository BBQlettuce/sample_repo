class Exchange < ActiveRecord::Base
end
