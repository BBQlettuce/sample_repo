class WatchListItem < ActiveRecord::Base
end
