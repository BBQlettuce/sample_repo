PostApp.Models.Post = Backbone.Model.extend({
  urlRoot: '/api/posts'
});
